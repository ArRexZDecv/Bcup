package com.rex.launcher

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView

class EmulatorSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : SurfaceView(context, attrs, defStyleAttr), SurfaceHolder.Callback {

    private var renderThread: Thread? = null

    @Volatile
    private var isRendering = false

    @Volatile
    private var isSurfaceAvailable = false

    var targetFps: Int = 60
        set(value) {
            field = if (value in setOf(30, 60, 120)) value else 60
        }

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        Log.i(TAG, "SurfaceView created, menghubungkan ke native core")
        isSurfaceAvailable = true
        MelonDSNative.nativeSetSurface(holder.surface)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        Log.i(TAG, "SurfaceView changed: ${width}x$height")
        MelonDSNative.nativeInit(width, height)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        Log.i(TAG, "SurfaceView destroyed, menghentikan rendering thread")
        isSurfaceAvailable = false
        stopEmulation()
        MelonDSNative.nativeSetSurface(null)
    }

    /**
     * Memulai emulasi dan thread rendering frame.
     */
    fun startEmulation() {
        if (isRendering) return
        isRendering = true
        MelonDSNative.nativeStart()

        renderThread = Thread({
            val frameIntervalNs = 1_000_000_000L / targetFps

            while (isRendering && isSurfaceAvailable) {
                val frameStartNs = System.nanoTime()

                // Render frame langsung dari buffer internal C++
                MelonDSNative.nativeRenderFrame()

                val elapsedNs = System.nanoTime() - frameStartNs
                val sleepTimeNs = frameIntervalNs - elapsedNs
                if (sleepTimeNs > 0) {
                    val sleepMs = sleepTimeNs / 1_000_000L
                    val sleepNano = (sleepTimeNs % 1_000_000L).toInt()
                    try {
                        Thread.sleep(sleepMs, sleepNano)
                    } catch (e: InterruptedException) {
                        Thread.currentThread().interrupt()
                        break
                    }
                }
            }
            Log.i(TAG, "Thread rendering selesai")
        }, "MelonDSRenderThread").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    /**
     * Menjeda rendering emulasi.
     */
    fun pauseEmulation() {
        isRendering = false
        renderThread?.interrupt()
        renderThread = null
        MelonDSNative.nativePause()
    }

    /**
     * Menghentikan emulasi dan melepaskan resource.
     */
    fun stopEmulation() {
        isRendering = false
        renderThread?.interrupt()
        renderThread = null
        MelonDSNative.nativeStop()
    }

    companion object {
        private const val TAG = "EmulatorSurfaceView"
    }
}
