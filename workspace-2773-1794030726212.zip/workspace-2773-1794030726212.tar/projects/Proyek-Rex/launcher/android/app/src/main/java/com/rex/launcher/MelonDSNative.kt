package com.rex.launcher

import android.util.Log
import android.view.Surface

object MelonDSNative {

    private const val TAG = "MelonDSNative"

    init {
        try {
            System.loadLibrary("melonds_core")
            Log.i(TAG, "Library native melonds_core berhasil dimuat")
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "Gagal memuat library native melonds_core", e)
        }
    }

    /**
     * Menginisialisasi dimensi dan buffer internal core emulator.
     */
    external fun nativeInit(width: Int, height: Int): Boolean

    /**
     * Menghubungkan Surface rendering Android (ANativeWindow) ke core C++.
     */
    external fun nativeSetSurface(surface: Surface?)

    /**
     * Memuat file ROM Nintendo DS (.nds) dari path lokal.
     */
    external fun nativeLoadRom(path: String): Boolean

    /**
     * Memulai loop emulasi.
     */
    external fun nativeStart()

    /**
     * Menjeda sementara loop emulasi.
     */
    external fun nativePause()

    /**
     * Menghentikan emulasi dan mereset status core.
     */
    external fun nativeStop()

    /**
     * Merender frame video aktif langsung ke buffer Surface.
     */
    external fun nativeRenderFrame()

    /**
     * Mengirimkan input tombol fisik/virtual gamepad ke core NDS.
     */
    external fun nativeSendInput(buttonCode: Int, pressed: Boolean)

    /**
     * Memperbarui konfigurasi backend grafik dan performa (Vulkan/OpenGL, FPS limit, touch overlay).
     */
    external fun nativeSetSettings(renderer: String, targetFps: Int, overlay: Boolean)

    /**
     * Mengecek apakah ROM saat ini telah dimuat ke dalam memori core.
     */
    external fun nativeIsRomLoaded(): Boolean
}
