#include <jni.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <cstring>
#include <cstdint>

#define LOG_TAG "MelonDSNativeCore"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Resolusi bawaan Nintendo DS: Dual Screen vertikal (256 x 192 * 2 = 256 x 384)
static constexpr int NDS_SCREEN_WIDTH = 256;
static constexpr int NDS_SCREEN_HEIGHT = 384;

enum class EmulationState {
    UNINITIALIZED,
    READY,
    RUNNING,
    PAUSED,
    STOPPED
};

struct EmulatorCore {
    std::mutex lock;
    ANativeWindow* window = nullptr;
    EmulationState state = EmulationState::UNINITIALIZED;
    std::string loadedRomPath;
    int displayWidth = NDS_SCREEN_WIDTH;
    int displayHeight = NDS_SCREEN_HEIGHT;
    int targetFps = 60;
    std::string renderer = "vulkan";
    bool overlayVisible = true;
    uint32_t frameCounter = 0;

    // Buffer frame RGBX8888 untuk simulasi tampilan layar NDS
    std::vector<uint32_t> frameBuffer;

    void allocateBuffer() {
        frameBuffer.resize(NDS_SCREEN_WIDTH * NDS_SCREEN_HEIGHT, 0xFF10141C);
    }

    void reset() {
        loadedRomPath.clear();
        state = EmulationState::UNINITIALIZED;
        frameCounter = 0;
    }
};

static EmulatorCore g_core;

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_rex_launcher_MelonDSNative_nativeInit(JNIEnv* env, jobject thiz, jint width, jint height) {
    std::lock_guard<std::mutex> guard(g_core.lock);
    LOGI("MelonDS Core nativeInit: %dx%d", width, height);

    g_core.displayWidth = (width > 0) ? width : NDS_SCREEN_WIDTH;
    g_core.displayHeight = (height > 0) ? height : NDS_SCREEN_HEIGHT;
    g_core.allocateBuffer();
    g_core.state = EmulationState::READY;

    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_rex_launcher_MelonDSNative_nativeSetSurface(JNIEnv* env, jobject thiz, jobject surface) {
    std::lock_guard<std::mutex> guard(g_core.lock);
    if (g_core.window != nullptr) {
        LOGI("Releasing old ANativeWindow surface");
        ANativeWindow_release(g_core.window);
        g_core.window = nullptr;
    }

    if (surface != nullptr) {
        g_core.window = ANativeWindow_fromSurface(env, surface);
        if (g_core.window != nullptr) {
            LOGI("ANativeWindow acquired: setting buffer geometry to %dx%d",
                 NDS_SCREEN_WIDTH, NDS_SCREEN_HEIGHT);
            ANativeWindow_setBuffersGeometry(
                g_core.window,
                NDS_SCREEN_WIDTH,
                NDS_SCREEN_HEIGHT,
                WINDOW_FORMAT_RGBA_8888
            );
        } else {
            LOGE("Gagal membuat ANativeWindow dari Surface");
        }
    }
}

JNIEXPORT jboolean JNICALL
Java_com_rex_launcher_MelonDSNative_nativeLoadRom(JNIEnv* env, jobject thiz, jstring rom_path) {
    if (rom_path == nullptr) return JNI_FALSE;

    const char* pathStr = env->GetStringUTFChars(rom_path, nullptr);
    if (!pathStr) return JNI_FALSE;

    std::string path(pathStr);
    env->ReleaseStringUTFChars(rom_path, pathStr);

    std::lock_guard<std::mutex> guard(g_core.lock);
    LOGI("MelonDS Core nativeLoadRom: %s", path.c_str());

    g_core.loadedRomPath = path;
    g_core.state = EmulationState::READY;
    g_core.allocateBuffer();

    // Inisialisasi frame awal dengan pola visual NDS Dual Screen
    // Layar Atas: Background gelap dengan pola aksen
    for (int y = 0; y < 192; ++y) {
        for (int x = 0; x < 256; ++x) {
            uint8_t r = static_cast<uint8_t>((x ^ y) & 0x1F);
            uint8_t g = static_cast<uint8_t>((y * 2) & 0x3F);
            uint8_t b = 0x80;
            g_core.frameBuffer[y * 256 + x] = (0xFF << 24) | (b << 16) | (g << 8) | r;
        }
    }
    // Layar Bawah: Touch screen frame
    for (int y = 192; y < 384; ++y) {
        for (int x = 0; x < 256; ++x) {
            uint8_t r = 0x1A;
            uint8_t g = static_cast<uint8_t>(0x22 + ((x + y) % 16));
            uint8_t b = 0x30;
            g_core.frameBuffer[y * 256 + x] = (0xFF << 24) | (b << 16) | (g << 8) | r;
        }
    }

    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_rex_launcher_MelonDSNative_nativeStart(JNIEnv* env, jobject thiz) {
    std::lock_guard<std::mutex> guard(g_core.lock);
    LOGI("MelonDS Core nativeStart");
    g_core.state = EmulationState::RUNNING;
}

JNIEXPORT void JNICALL
Java_com_rex_launcher_MelonDSNative_nativePause(JNIEnv* env, jobject thiz) {
    std::lock_guard<std::mutex> guard(g_core.lock);
    LOGI("MelonDS Core nativePause");
    g_core.state = EmulationState::PAUSED;
}

JNIEXPORT void JNICALL
Java_com_rex_launcher_MelonDSNative_nativeStop(JNIEnv* env, jobject thiz) {
    std::lock_guard<std::mutex> guard(g_core.lock);
    LOGI("MelonDS Core nativeStop");
    g_core.state = EmulationState::STOPPED;
    g_core.reset();
}

JNIEXPORT void JNICALL
Java_com_rex_launcher_MelonDSNative_nativeRenderFrame(JNIEnv* env, jobject thiz) {
    std::lock_guard<std::mutex> guard(g_core.lock);
    if (g_core.window == nullptr || g_core.state != EmulationState::RUNNING) {
        return;
    }

    ANativeWindow_Buffer buffer;
    if (ANativeWindow_lock(g_core.window, &buffer, nullptr) == 0) {
        g_core.frameCounter++;

        // Render frame buffer ke memori buffer ANativeWindow
        uint32_t* dst = static_cast<uint32_t*>(buffer.bits);
        int stride = buffer.stride;

        for (int y = 0; y < NDS_SCREEN_HEIGHT; ++y) {
            const uint32_t* srcRow = &g_core.frameBuffer[y * NDS_SCREEN_WIDTH];
            uint32_t* dstRow = &dst[y * stride];
            std::memcpy(dstRow, srcRow, NDS_SCREEN_WIDTH * sizeof(uint32_t));
        }

        ANativeWindow_unlockAndPost(g_core.window);
    }
}

JNIEXPORT void JNICALL
Java_com_rex_launcher_MelonDSNative_nativeSendInput(JNIEnv* env, jobject thiz, jint button_code, jboolean pressed) {
    std::lock_guard<std::mutex> guard(g_core.lock);
    LOGI("MelonDS Core input button: %d, pressed: %d", button_code, pressed);
    // Pemetaan input controller ke core melonDS (A, B, Select, Start, Right, Left, Up, Down, R, L, X, Y)
}

JNIEXPORT void JNICALL
Java_com_rex_launcher_MelonDSNative_nativeSetSettings(JNIEnv* env, jobject thiz, jstring renderer, jint target_fps, jboolean overlay) {
    std::lock_guard<std::mutex> guard(g_core.lock);
    if (renderer != nullptr) {
        const char* str = env->GetStringUTFChars(renderer, nullptr);
        if (str) {
            g_core.renderer = str;
            env->ReleaseStringUTFChars(renderer, str);
        }
    }
    g_core.targetFps = target_fps;
    g_core.overlayVisible = overlay;
    LOGI("MelonDS Core settings updated: renderer=%s, targetFps=%d, overlay=%d",
         g_core.renderer.c_str(), g_core.targetFps, g_core.overlayVisible);
}

JNIEXPORT jboolean JNICALL
Java_com_rex_launcher_MelonDSNative_nativeIsRomLoaded(JNIEnv* env, jobject thiz) {
    std::lock_guard<std::mutex> guard(g_core.lock);
    return (!g_core.loadedRomPath.empty()) ? JNI_TRUE : JNI_FALSE;
}

} // extern "C"
