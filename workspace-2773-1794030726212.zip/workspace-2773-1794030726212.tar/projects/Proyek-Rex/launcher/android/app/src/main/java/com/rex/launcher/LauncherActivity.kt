package com.rex.launcher

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewAssetLoader.AssetsPathHandler
import androidx.webkit.WebViewAssetLoader.InternalStoragePathHandler
import androidx.webkit.WebViewClientCompat
import java.io.File

class LauncherActivity : ComponentActivity() {

    private lateinit var bridge: LauncherBridge
    private lateinit var webView: WebView
    private lateinit var emulatorSurfaceView: EmulatorSurfaceView
    private lateinit var settings: LauncherSettings

    private val backPressedCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            if (emulatorSurfaceView.visibility == View.VISIBLE) {
                // Jika emulator sedang berjalan, kembali ke tampilan Dashboard WebView
                exitEmulator()
            } else {
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
                isEnabled = true
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        settings = LauncherSettings(this)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", AssetsPathHandler(this))
            .addPathHandler(
                "/${LauncherBridge.COVER_PATH}/",
                InternalStoragePathHandler(this, File(filesDir, LauncherBridge.COVER_PATH)),
            )
            .build()

        webView = WebView(this)
        bridge = LauncherBridge(this, webView, settings)

        webView.apply {
            this.settings.javaScriptEnabled = true
            this.settings.domStorageEnabled = true
            webViewClient = object : WebViewClientCompat() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    assetLoader.shouldInterceptRequest(request.url)

                override fun onPageFinished(view: WebView?, url: String?) {
                    bridge.publishState()
                }
            }
            addJavascriptInterface(bridge, "Android")
            loadUrl("${LauncherBridge.ASSET_ORIGIN}/assets/launcher/index.html")
        }

        // Komponen SurfaceView untuk rendering game NDS mandiri (standalone)
        emulatorSurfaceView = EmulatorSurfaceView(this).apply {
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val rootLayout = FrameLayout(this).apply {
            addView(
                webView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            addView(emulatorSurfaceView)
        }

        setContentView(rootLayout)
        onBackPressedDispatcher.addCallback(this, backPressedCallback)
    }

    /**
     * Memulai emulasi NDS mandiri secara langsung di dalam SurfaceView tanpa memanggil intent eksternal.
     */
    fun launchEmbeddedGame(romPath: String): Boolean {
        Log.i(TAG, "Meluncurkan game standalone: $romPath")

        // Kirim pengaturan aktif ke C++ core
        val currentFps = settings.getTargetFps()
        emulatorSurfaceView.targetFps = currentFps
        MelonDSNative.nativeSetSettings(
            settings.getRenderer(),
            currentFps,
            settings.isOverlayVisible()
        )

        // Muat ROM ke dalam memory emulator C++
        val loaded = MelonDSNative.nativeLoadRom(romPath)
        if (!loaded) {
            Log.e(TAG, "Gagal memuat ROM ke dalam native core: $romPath")
            return false
        }

        // Alihkan tampilan: sembunyikan UI launcher web dan tampilkan surface emulator
        webView.visibility = View.GONE
        emulatorSurfaceView.visibility = View.VISIBLE
        emulatorSurfaceView.startEmulation()

        return true
    }

    /**
     * Menghentikan emulasi dan kembali ke UI Dashboard WebView.
     */
    fun exitEmulator() {
        Log.i(TAG, "Menutup emulator, kembali ke dashboard launcher")
        emulatorSurfaceView.stopEmulation()
        emulatorSurfaceView.visibility = View.GONE
        webView.visibility = View.VISIBLE
    }

    override fun onPause() {
        super.onPause()
        if (emulatorSurfaceView.visibility == View.VISIBLE) {
            emulatorSurfaceView.pauseEmulation()
        }
    }

    override fun onResume() {
        super.onResume()
        if (emulatorSurfaceView.visibility == View.VISIBLE) {
            emulatorSurfaceView.startEmulation()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        emulatorSurfaceView.stopEmulation()
    }

    companion object {
        private const val TAG = "LauncherActivity"
    }
}
